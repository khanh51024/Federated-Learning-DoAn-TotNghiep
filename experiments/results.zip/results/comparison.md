| Cấu hình | Accuracy | Macro-F1 |
|---|---:|---:|
| Centralized | 0.9838 | 0.9790 |
| FedAvg | 0.9921 | 0.9893 |
| Local-only avg | 0.8938 | 0.8561 |
